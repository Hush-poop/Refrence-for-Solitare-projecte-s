# Solitaire
##Hello everyone!
This is a basic Solitaire game I have written in JavaScript (using the p5 framework to display it on my canvas).

The code is very simple, but I want to make an Admiral game as well, so the basics will not change (like deck or Card).

Happy cardplaying!
